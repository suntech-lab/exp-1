<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="doodle tiles" tilewidth="500" tileheight="477" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1">
  <image width="500" height="111" source="grass.png"/>
 </tile>
 <tile id="2">
  <image width="499" height="477" source="crayonchunk.png"/>
 </tile>
 <tile id="3">
  <image width="500" height="401" source="moose.png"/>
 </tile>
</tileset>
