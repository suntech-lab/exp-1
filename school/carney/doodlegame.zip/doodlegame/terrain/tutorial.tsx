<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tutorial" tilewidth="681" tileheight="576" tilecount="13" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="500" height="409" source="arrowkeyssign.png"/>
 </tile>
 <tile id="1">
  <image width="493" height="331" source="cow1.png"/>
 </tile>
 <tile id="2">
  <image width="499" height="477" source="crayonchunk.png"/>
 </tile>
 <tile id="3">
  <image width="500" height="401" source="moose.png"/>
 </tile>
 <tile id="4">
  <image width="500" height="236" source="jumpsign.png"/>
 </tile>
 <tile id="5">
  <image width="500" height="111" source="grass.png"/>
 </tile>
 <tile id="6">
  <image width="338" height="500" source="rsign.png"/>
 </tile>
 <tile id="7">
  <image width="487" height="500" source="plussign.png"/>
 </tile>
 <tile id="8">
  <image width="380" height="500" source="nsign.png"/>
 </tile>
 <tile id="9">
  <image width="425" height="500" source="usign.png"/>
 </tile>
 <tile id="10">
  <image width="500" height="423" source="wasdsign.png"/>
 </tile>
 <tile id="11">
  <image width="681" height="576" source="me.png"/>
 </tile>
 <tile id="12">
  <image width="360" height="360" source="scissors.png"/>
 </tile>
</tileset>
